SMODS.Joker{ --57 Leaf Clover
    key = "_57leafclover",
    config = {
        extra = {
            xMult = 1
        }
    },
    loc_txt = {
        ['name'] = '57 Leaf Clover',
        ['text'] = {
            [1] = 'This Joker gains {X:red,C:white}X0.02{} Mult every time a {C:attention}Lucky{}',
            [2] = 'card fails to trigger {C:inactive}(Currently {}{X:mult,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xMult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_lucky"] == true and not (context.other_card.lucky_trigger)) then
                card.ability.extra.xMult = (card.ability.extra.xMult) + 0.02
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xMult
                }
        end
    end
}