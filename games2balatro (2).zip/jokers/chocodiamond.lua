SMODS.Joker{ --Choco Diamond
    key = "chocodiamond",
    config = {
        extra = {
            xMult = 1.4
        }
    },
    loc_txt = {
        ['name'] = 'Choco Diamond',
        ['text'] = {
            [1] = 'Each played card of {C:diamonds}Diamond{} suit gives {X:red,C:white}X#1#{} Mult',
            [2] = 'when scored. Reduces by {X:red,C:white}X0.08{} each round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xMult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Diamonds") then
                return {
                    Xmult = card.ability.extra.xMult
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (card.ability.extra.xMult or 0) <= 1 then
                return {
                    func = function()
                card:undefined()
                return true
            end
                }
            else
                return {
                    func = function()
                    card.ability.extra.xMult = math.max(0, (card.ability.extra.xMult) - 0.08)
                    return true
                end
                }
            end
        end
    end
}