SMODS.Joker{ --Frequencies
    key = "frequencies",
    config = {
        extra = {
            ChipOrMult = 0,
            chips_min = 5,
            chips_max = 40,
            mult_min = 1,
            mult_max = 8
        }
    },
    loc_txt = {
        ['name'] = 'Frequencies',
        ['text'] = {
            [1] = 'Each scored card gives {C:blue}+5-40{} Chips or {C:red}+1-8{} Mult when scored.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                card.ability.extra.ChipOrMult = pseudorandom('ChipOrMult_331c54fd', 0, 1)
        end
        if context.individual and context.cardarea == G.play  then
            if (card.ability.extra.ChipOrMult or 0) == 0 then
                card.ability.extra.ChipOrMult = pseudorandom('ChipOrMult_7ad30f45', 0, 1)
                return {
                    chips = pseudorandom('chips_5554cbb5', card.ability.extra.chips_min, card.ability.extra.chips_max)
                }
            elseif (card.ability.extra.ChipOrMult or 0) == 1 then
                card.ability.extra.ChipOrMult = pseudorandom('ChipOrMult_9d4e49be', 0, 1)
                return {
                    mult = pseudorandom('mult_d038d1e9', card.ability.extra.mult_min, card.ability.extra.mult_max)
                }
            end
        end
    end
}