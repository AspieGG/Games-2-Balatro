SMODS.Joker{ --New Home
    key = "newhome",
    config = {
        extra = {
            fullhouselevel = 0
        }
    },
    loc_txt = {
        ['name'] = 'New Home',
        ['text'] = {
            [1] = 'Each played card adds{C:red} Mult {}equal to Full House level{C:inactive}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                return {
                    mult = G.GAME.hands['Full House'].level
                }
        end
    end
}