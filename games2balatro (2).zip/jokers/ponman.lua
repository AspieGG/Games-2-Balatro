SMODS.Joker{ --Ponman
    key = "ponman",
    config = {
        extra = {
            Chips = 0,
            First = 0
        }
    },
    loc_txt = {
        ['name'] = 'Ponman',
        ['text'] = {
            [1] = 'This Joker gains {C:blue}+1{} Chips every time a card is scored.',
            [2] = 'Double scaling on the first hand of round {C:inactive}(Currently {}{C:blue}+#1#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chips}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (card.ability.extra.First or 0) == 0 then
                card.ability.extra.Chips = (card.ability.extra.Chips) + 1
            elseif (card.ability.extra.First or 0) == 1 then
                card.ability.extra.Chips = (card.ability.extra.Chips) + 2
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.current_round.hands_played == 0 then
                card.ability.extra.First = 1
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if (card.ability.extra.First or 0) ~= 0 then
                return {
                    func = function()
                    card.ability.extra.First = 0
                    return true
                end
                }
            end
        end
    end
}