SMODS.Joker{ --Sweetheart
    key = "sweetheart",
    config = {
        extra = {
            repetitions = 1,
            mult = 12
        }
    },
    loc_txt = {
        ['name'] = 'Sweetheart',
        ['text'] = {
            [1] = 'Retrigger each played card of {C:hearts}Heart{} suit. Each played',
            [2] = 'card of {C:hearts}Heart{} suit gives {C:red}+12{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}