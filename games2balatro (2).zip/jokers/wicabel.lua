SMODS.Joker{ --Wicabel
    key = "wicabel",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Wicabel',
        ['text'] = {
            [1] = 'Each played 10 gives {C:blue}+28{} Chips and {C:red}+10{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers'
}