SMODS.Joker{ --Arcane Orb
    key = "arcaneorb",
    config = {
        extra = {
            Chips = 0,
            xMult = 1,
            Chips2Mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Arcane Orb',
        ['text'] = {
            [1] = 'This Joker gains {C:blue}+13{} Chips whenever a {C:tarot}Tarot{} card',
            [2] = 'is used. When round ends, convert all Chips into {X:red,C:white}X0.01{} Mult each',
            [3] = '(Currently {C:blue}+#1#{} Chips, {X:red,C:white}X#2#{} Mult)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chips, card.ability.extra.xMult}}
    end,

    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Tarot' then
                return {
                    func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 13
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.Chips2Mult = (card.ability.extra.Chips2Mult) + 0.13
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                local Chips2Mult_value = card.ability.extra.Chips2Mult
                return {
                    func = function()
                    card.ability.extra.xMult = (card.ability.extra.xMult) + card.ability.extra.Chips2Mult
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.Chips = 0
                    return true
                end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.Chips2Mult = 0
                    return true
                end,
                            colour = G.C.BLUE
                        }
                        }
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.Chips,
                    extra = {
                        Xmult = card.ability.extra.xMult
                        }
                }
        end
    end
}