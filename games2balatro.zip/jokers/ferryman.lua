SMODS.Joker{ --Ferryman
    key = "ferryman",
    config = {
        extra = {
            dollars = 15
        }
    },
    loc_txt = {
        ['name'] = 'Ferryman',
        ['text'] = {
            [1] = 'Earn {C:money}$15{} whenever a Blind is skipped.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.skip_blind  then
                return {
                    dollars = card.ability.extra.dollars
                }
        end
    end
}