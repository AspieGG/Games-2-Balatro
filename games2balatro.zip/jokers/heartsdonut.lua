SMODS.Joker{ --Hearts Donut
    key = "heartsdonut",
    config = {
        extra = {
            Mult = 7
        }
    },
    loc_txt = {
        ['name'] = 'Hearts Donut',
        ['text'] = {
            [1] = 'Each played card of {C:hearts}Heart{} suit gives {C:red}+#1#{} Mult',
            [2] = 'when scored. Reduces by {C:red}1{} at end of round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Mult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    mult = card.ability.extra.Mult
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (card.ability.extra.Mult or 0) <= 0 then
                return {
                    func = function()
                card:undefined()
                return true
            end
                }
            else
                return {
                    func = function()
                    card.ability.extra.Mult = math.max(0, (card.ability.extra.Mult) - 1)
                    return true
                end
                }
            end
        end
    end
}