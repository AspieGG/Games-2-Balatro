SMODS.Joker{ --Sharpshooter
    key = "sharpshooter",
    config = {
        extra = {
            mult = 11
        }
    },
    loc_txt = {
        ['name'] = 'Sharpshooter',
        ['text'] = {
            [1] = 'Each played Ace gives {C:red}+11{} Mult when scored.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 14 then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}