SMODS.Joker{ --Visage
    key = "visage",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Visage',
        ['text'] = {
            [1] = 'If first discard of round contains 5 face cards,',
            [2] = 'create a {C:spectral}Spectral{} card {C:inactive}(Must have room){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.pre_discard  then
            if (G.GAME.current_round.discards_used <= 0 and (function()
    local rankCount = 0
    for i, c in ipairs(context.full_hand) do
        if c:is_face() then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 5
end)()) then
                return {
                    func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Spectral', soulable = undefined, key = nil, key_append = 'joker_forge_spectral'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_spectral'), colour = G.C.SECONDARY_SET.Spectral})
                    end
                    return true
                end
                }
            end
        end
    end
}