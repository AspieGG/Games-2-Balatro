SMODS.Joker{ --Axis-014
    key = "axis014",
    config = {
        extra = {
            mult = 14
        }
    },
    loc_txt = {
        ['name'] = 'Axis-014',
        ['text'] = {
            [1] = '{C:attention}Gold{} cards held in hand each give {C:red}+14{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_gold"] == true then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}