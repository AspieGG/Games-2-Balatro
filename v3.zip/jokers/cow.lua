SMODS.Joker{ --Cow
    key = "cow",
    config = {
        extra = {
            dollars = 2,
            dollars2 = 4,
            dollars3 = 6,
            dollars4 = 8,
            dollars5 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Cow',
        ['text'] = {
            [1] = 'Earn {C:money}$2{} per unscored card in played hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (#context.full_hand - #context.scoring_hand) == 1 then
                return {
                    dollars = card.ability.extra.dollars
                }
            elseif (#context.full_hand - #context.scoring_hand) == 2 then
                return {
                    dollars = card.ability.extra.dollars2
                }
            elseif (#context.full_hand - #context.scoring_hand) == 3 then
                return {
                    dollars = card.ability.extra.dollars3
                }
            elseif (#context.full_hand - #context.scoring_hand) == 4 then
                return {
                    dollars = card.ability.extra.dollars4
                }
            elseif (#context.full_hand - #context.scoring_hand) == 5 then
                return {
                    dollars = card.ability.extra.dollars5
                }
            end
        end
    end
}