SMODS.Joker{ --Cyborg
    key = "cyborg",
    config = {
        extra = {
            enhancedcardsindeck = 0
        }
    },
    loc_txt = {
        ['name'] = 'Cyborg',
        ['text'] = {
            [1] = '{C:red}+5{} Mult per {C:enhanced}Enhanced{} card in full deck{C:inactive} (Currently {}{C:red}+#1#{} {C:inactive}Mult){}{C:inactive}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if next(SMODS.get_enhancements(card)) then count = count + 1 end end; return count end)()) * 5}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if next(SMODS.get_enhancements(card)) then count = count + 1 end end; return count end)()) * 5
                }
        end
    end
}