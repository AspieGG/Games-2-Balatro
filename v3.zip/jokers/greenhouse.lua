SMODS.Joker{ --Greenhouse
    key = "greenhouse",
    config = {
        extra = {
            pb_mult_04a4566f = 1,
            perma_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Greenhouse',
        ['text'] = {
            [1] = 'Each played face card permanently gains {C:red}+1{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.pb_mult_04a4566f
                return {
                    extra = { message = "Grow!", colour = G.C.MULT }, card = card
                }
            end
        end
    end
}