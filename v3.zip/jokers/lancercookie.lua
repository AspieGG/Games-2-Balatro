SMODS.Joker{ --Lancer Cookie
    key = "lancercookie",
    config = {
        extra = {
            Chance = 6,
            dollars = 1,
            odds = 6,
            dollars2 = 1,
            odds2 = 6,
            dollars3 = 1,
            odds3 = 6,
            dollars4 = 1,
            odds4 = 6,
            dollars5 = 1,
            dollars6 = 5,
            odds5 = 6,
            dollars7 = 1,
            start_dissolve = 0,
            y = 0
        }
    },
    loc_txt = {
        ['name'] = 'Lancer Cookie',
        ['text'] = {
            [1] = 'Each played card of {C:spades}Spade{} suit has a {C:green}#1# in 6{} chance',
            [2] = 'to give {C:money}$1{} when scored. Reduces by {C:green}1 in 6{} each round.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chance}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:is_suit("Spades") and (card.ability.extra.Chance or 0) == 6) then
                return {
                    dollars = card.ability.extra.dollars
                }
            elseif (context.other_card:is_suit("Spades") and (card.ability.extra.Chance or 0) == 5) then
                if SMODS.pseudorandom_probability(card, 'group_0_ebddf3ee', 5, card.ability.extra.odds, 'j_g2b_lancercookie', false) then
              SMODS.calculate_effect({dollars = card.ability.extra.dollars2}, card)
          end
            elseif (context.other_card:is_suit("Spades") and (card.ability.extra.Chance or 0) == 4) then
                if SMODS.pseudorandom_probability(card, 'group_0_b68165cf', 4, card.ability.extra.odds, 'j_g2b_lancercookie', false) then
              SMODS.calculate_effect({dollars = card.ability.extra.dollars3}, card)
          end
            elseif (context.other_card:is_suit("Spades") and (card.ability.extra.Chance or 0) == 3) then
                if SMODS.pseudorandom_probability(card, 'group_0_ce1a1fa2', 3, card.ability.extra.odds, 'j_g2b_lancercookie', false) then
              SMODS.calculate_effect({dollars = card.ability.extra.dollars4}, card)
          end
            elseif (context.other_card:is_suit("Spades") and (card.ability.extra.Chance or 0) == 2) then
                if SMODS.pseudorandom_probability(card, 'group_0_81697193', 2, card.ability.extra.odds, 'j_g2b_lancercookie', false) then
              SMODS.calculate_effect({dollars = card.ability.extra.dollars5}, card)
          end
            elseif (context.other_card:is_suit("Spades") and (card.ability.extra.Chance or 0) == 1) then
                return {
                    dollars = card.ability.extra.dollars6
                ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_019d9c50', 1, card.ability.extra.odds, 'j_g2b_lancercookie', false) then
              SMODS.calculate_effect({dollars = card.ability.extra.dollars7}, card)
          end
                        return true
                    end
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (card.ability.extra.Chance or 0) <= 1 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Lancered!"
                }
            else
                return {
                    func = function()
                    card.ability.extra.Chance = math.max(0, (card.ability.extra.Chance) - 1)
                    return true
                end
                }
            end
        end
    end
}