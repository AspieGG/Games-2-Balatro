SMODS.Joker{ --Dungeon
    key = "dungeon",
    config = {
        extra = {
            Size = 1,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Dungeon',
        ['text'] = {
            [1] = '{C:attention}+#1#{} hand size',
            [2] = 'Increases by 1 every time a {C:spectral}Spectral{} card is used'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Size}}
    end,

    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Spectral' then
                return {
                    func = function()
                    card.ability.extra.var1 = (card.ability.extra.var1) + 1
                    return true
                end
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(card.ability.extra.Size)
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-card.ability.extra.Size)
    end
}