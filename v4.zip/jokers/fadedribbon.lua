SMODS.Joker{ --Faded Ribbon
    key = "fadedribbon",
    config = {
        extra = {
            sell_value = 1
        }
    },
    loc_txt = {
        ['name'] = 'Faded Ribbon',
        ['text'] = {
            [1] = 'Increase sell value by {C:money}$1{} if played hand contains a {C:attention}Flush{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Flush"]) then
                local my_pos = nil
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] == card then
                my_pos = i
                break
            end
        end
        local target_card = G.jokers.cards[my_post]for i, target_card in ipairs(area.cards) do
                if target_card.set_cost then
            target_joker.ability.extra_value = (card.ability.extra_value or 0) + card.ability.extra.sell_value
            target_joker:set_cost()
            end
        end
                return {
                    message = "+"..tostring(card.ability.extra.sell_value).." Sell Value"
                }
            end
        end
    end
}