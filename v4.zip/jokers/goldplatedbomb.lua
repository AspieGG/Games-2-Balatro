SMODS.Joker{ --Gold-Plated Bomb
    key = "goldplatedbomb",
    config = {
        extra = {
            dollars = 0,
            explode = 0,
            y = 0
        }
    },
    loc_txt = {
        ['name'] = 'Gold-Plated Bomb',
        ['text'] = {
            [1] = 'Prevent death if you have at least {C:money}$50{}. Lose {C:attention}all money{} on death. {C:red}Self-destructs{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over and context.main_eval  then
            if G.GAME.dollars >= to_big(50) then
                return {
                    saved = true,
                    message = localize('k_saved_ex'),
                    extra = {
                        func = function()
                    local target_amount = card.ability.extra.dollars
                    local current_amount = G.GAME.dollars
                    local difference = target_amount - current_amount
                    ease_dollars(difference)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to $"..tostring(card.ability.extra.dollars), colour = G.C.MONEY})
                    return true
                end,
                        colour = G.C.MONEY,
                        extra = {
                            func = function()
                card:explode()
                return true
            end,
                            message = "Boom!",
                            colour = G.C.RED
                        }
                        }
                }
            end
        end
    end
}