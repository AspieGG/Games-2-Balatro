SMODS.Joker{ --Guei
    key = "guei",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Guei',
        ['text'] = {
            [1] = 'Create a {C:spectral}Spectral{} card if played hand contains a {C:attention}7{},',
            [2] = 'a card of {C:attention}#1# {}suit {}and a {C:attention}Straight{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {localize((G.GAME.current_round.Suit_card or {}).suit or 'Spades', 'suits_singular')}, colours = {G.C.SUITS[(G.GAME.current_round.Suit_card or {}).suit or 'Spades']}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.Suit_card = { suit = 'Spades' }
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local rankFound = false
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 7 then
            rankFound = true
            break
        end
    end
    
    return rankFound
end)() and next(context.poker_hands["Straight"]) and (function()
    local suitCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:is_suit(G.GAME.current_round.Suit_card.suit) then
            suitCount = suitCount + 1
        end
    end
    
    return suitCount >= 1
end)()) then
            end
        end
    end
}