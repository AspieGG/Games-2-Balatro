SMODS.Joker{ --Guzzlord
    key = "guzzlord",
    config = {
        extra = {
            levels = 1,
            levels2 = 1,
            levels3 = 1,
            levels4 = 1,
            levels5 = 1,
            levels6 = 1,
            levels7 = 1,
            levels8 = 1,
            levels9 = 1,
            levels10 = 1,
            levels11 = 1,
            levels12 = 1,
            levels13 = 1,
            yes = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Guzzlord',
        ['text'] = {
            [1] = 'When Blind is selected, {C:attention}consume{} Joker',
            [2] = 'to the right and level up{C:attention} all{} hands by 1'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.setting_blind  then
                target_hand = "Pair"
                target_hand2 = "High Card"
                target_hand3 = "Two Pair"
                target_hand4 = "Three of a Kind"
                target_hand5 = "Straight"
                target_hand6 = "Straight"
                target_hand7 = "Flush"
                target_hand8 = "Full House"
                target_hand9 = "Four of a Kind"
                target_hand10 = "Five of a Kind"
                target_hand11 = "Straight Flush"
                target_hand12 = "Flush House"
                target_hand13 = "Flush Five"
                return {
                    func = function()
                local my_pos = nil
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i] == card then
                        my_pos = i
                        break
                    end
                end
                local target_joker = nil
                if my_pos and my_pos < #G.jokers.cards then
                    local joker = G.jokers.cards[my_pos + 1]
                    if true and not joker.getting_sliced then
                        target_joker = joker
                    end
                end
                
                if target_joker then
                    if target_joker.ability.eternal then
                        target_joker.ability.eternal = nil
                    end
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
                    return true
                end,
                    extra = {
                        level_up = card.ability.extra.levels,
      level_up_hand = target_hand,
                            message = localize('k_level_up_ex'),
                        colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels2,
      level_up_hand = target_hand2,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels3,
      level_up_hand = target_hand3,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels4,
      level_up_hand = target_hand4,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels5,
      level_up_hand = target_hand5,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels6,
      level_up_hand = target_hand6,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels7,
      level_up_hand = target_hand7,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels8,
      level_up_hand = target_hand8,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels9,
      level_up_hand = target_hand9,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels10,
      level_up_hand = target_hand10,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels11,
      level_up_hand = target_hand11,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels12,
      level_up_hand = target_hand12,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                        extra = {
                            level_up = card.ability.extra.levels13,
      level_up_hand = target_hand13,
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                }
        end
    end
}