SMODS.Joker{ --Jakiro
    key = "jakiro",
    config = {
        extra = {
            pairplayed = 0
        }
    },
    loc_txt = {
        ['name'] = 'Jakiro',
        ['text'] = {
            [1] = '{C:blue}+5{} Chips and {C:red}+1{} Mult per Pair played this run (Currently {C:attention}#1#{}{C:attention}{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {((G.GAME.hands['Pair'].played or 0)) * 5}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = (G.GAME.hands['Pair'].played) * 5,
                    extra = {
                        mult = G.GAME.hands['Pair'].played
                        }
                }
        end
    end
}