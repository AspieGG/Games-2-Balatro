SMODS.Joker{ --Ledian
    key = "ledian",
    config = {
        extra = {
            chips = 15
        }
    },
    loc_txt = {
        ['name'] = 'Ledian',
        ['text'] = {
            [1] = 'Each played card of {C:diamonds}Diamond{} suit gives {C:blue}+15{} Chips when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Diamonds") then
                return {
                    chips = card.ability.extra.chips
                }
            end
        end
    end
}