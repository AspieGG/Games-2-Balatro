SMODS.Joker{ --Loaded Dice
    key = "loadeddice",
    config = {
        extra = {
            odds = 2,
            repetitions = 1
        }
    },
    loc_txt = {
        ['name'] = 'Loaded Dice',
        ['text'] = {
            [1] = 'Each played card has a {C:green}1 in 2{} chance to retrigger'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
                if SMODS.pseudorandom_probability(card, 'group_0_05a416d9', 1, card.ability.extra.odds, 'j_g2b_loadeddice', false) then
              return {repetitions = card.ability.extra.repetitions}
                        
          end
        end
    end
}