SMODS.Joker{ --Lucario
    key = "lucario",
    config = {
        extra = {
            Steel = 0,
            OncePerRound = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Lucario',
        ['text'] = {
            [1] = 'Once per Blind, create an {C:spectral}Aura{} card if',
            [2] = 'played hand triggers 2 or more {C:attention}Steel{} cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
            if ((card.ability.extra.var1 or 0) >= 2 and (card.ability.extra.OncePerRound or 0) == 0) then
                return {
                    func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Spectral', soulable = nil, key = 'c_aura', key_append = 'joker_forge_spectral'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_spectral'), colour = G.C.SECONDARY_SET.Spectral})
                    end
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.Steel = 0
                    return true
                end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.OncePerRound = 1
                    return true
                end,
                            colour = G.C.BLUE
                        }
                        }
                }
            elseif ((card.ability.extra.Steel or 0) <= 1 and (card.ability.extra.OncePerRound or 0) == 0) then
                return {
                    func = function()
                    card.ability.extra.Steel = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.OncePerRound = 1
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    func = function()
                    card.ability.extra.Steel = (card.ability.extra.Steel) + 1
                    return true
                end
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.OncePerRound = 0
                    return true
                end
                }
        end
    end
}