SMODS.Joker{ --Mirabelle
    key = "mirabelle",
    config = {
        extra = {
            dollars = 3
        }
    },
    loc_txt = {
        ['name'] = 'Mirabelle',
        ['text'] = {
            [1] = 'Earn {C:money}$3{} whenever a playing card is added to your deck'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.playing_card_added  then
                return {
                    dollars = card.ability.extra.dollars
                }
        end
    end
}