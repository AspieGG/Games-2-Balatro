SMODS.Joker{ --Mourning Wood
    key = "mourningwood",
    config = {
        extra = {
            Chips = 0,
            AlreadyTriggered = 0
        }
    },
    loc_txt = {
        ['name'] = 'Mourning Wood',
        ['text'] = {
            [1] = 'This Joker gains {C:attention}+13{} {C:blue}Chips{} whenever',
            [2] = 'one or more cards are destroyed',
            [3] = '{C:inactive}(Currently {}{C:blue}+#1#{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chips}}
    end,

    calculate = function(self, card, context)
        if context.remove_playing_cards  then
            if (card.ability.extra.AlreadyTriggered or 0) == 0 then
                return {
                    func = function()
                    card.ability.extra.AlreadyTriggered = (card.ability.extra.AlreadyTriggered) + 1
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 13
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                card.ability.extra.AlreadyTriggered = (card.ability.extra.AlreadyTriggered) + 0
                return {
                    chips = card.ability.extra.Chips
                }
        end
        if context.pre_discard  then
                return {
                    func = function()
                    card.ability.extra.AlreadyTriggered = (card.ability.extra.AlreadyTriggered) + 0
                    return true
                end
                }
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.AlreadyTriggered = (card.ability.extra.AlreadyTriggered) + 0
                    return true
                end
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.AlreadyTriggered = (card.ability.extra.AlreadyTriggered) + 0
                    return true
                end
                }
        end
        if context.using_consumeable  then
                return {
                    func = function()
                    card.ability.extra.AlreadyTriggered = (card.ability.extra.AlreadyTriggered) + 0
                    return true
                end
                }
        end
    end
}