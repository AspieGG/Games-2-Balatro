SMODS.Joker{ --Muffet
    key = "muffet",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Muffet',
        ['text'] = {
            [1] = 'Sets Joker slots to 8'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
    end,

    add_to_deck = function(self, card, from_debuff)
        card.ability.extra.original_joker_slots = G.jokers.config.card_limit
        G.jokers.config.card_limit = 8
    end,

    remove_from_deck = function(self, card, from_debuff)
        if card.ability.extra.original_joker_slots then
            G.jokers.config.card_limit = card.ability.extra.original_joker_slots
        end
    end
}