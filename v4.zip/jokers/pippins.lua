SMODS.Joker{ --Pippins
    key = "pippins",
    config = {
        extra = {
            mult_min = 2,
            mult_max = 12
        }
    },
    loc_txt = {
        ['name'] = 'Pippins',
        ['text'] = {
            [1] = 'Each played 2, 3, 7, Jack and Queen gives',
            [2] = 'between {C:red}+2{} and {C:red}+12{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 3 or context.other_card:get_id() == 7 or context.other_card:get_id() == 11 or context.other_card:get_id() == 12) then
                return {
                    mult = pseudorandom('mult_a71d47e3', card.ability.extra.mult_min, card.ability.extra.mult_max)
                }
            end
        end
    end
}