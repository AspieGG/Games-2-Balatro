SMODS.Joker{ --Prescriptions
    key = "prescriptions",
    config = {
        extra = {
            enhancedcardsindeck = 0
        }
    },
    loc_txt = {
        ['name'] = 'Prescriptions',
        ['text'] = {
            [1] = '{C:blue}+8{} Chips per {C:enhanced}Enhanced{} card in full deck {C:inactive}(Currently {}{C:blue}+#1#{}{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if next(SMODS.get_enhancements(card)) then count = count + 1 end end; return count end)()) * 8}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local count = 0
    for _, playing_card in pairs(G.playing_cards or {}) do
        if next(SMODS.get_enhancements(playing_card)) then
            count = count + 1
        end
    end
    return count > 0
end)() then
                return {
                    chips = ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if next(SMODS.get_enhancements(card)) then count = count + 1 end end; return count end)()) * 8
                }
            end
        end
    end
}