SMODS.Joker{ --Ruins Mouse Hole
    key = "ruinsmousehole",
    config = {
        extra = {
            levels = 1
        }
    },
    loc_txt = {
        ['name'] = 'Ruins Mouse Hole',
        ['text'] = {
            [1] = 'Level up first played hand of round if it contains a {C:attention}2{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (G.GAME.current_round.hands_played == 0 and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 2 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
                target_hand = (context.scoring_name or "High Card")
                return {
                    level_up = card.ability.extra.levels,
      level_up_hand = target_hand,
                    message = localize('k_level_up_ex')
                }
            end
        end
    end
}