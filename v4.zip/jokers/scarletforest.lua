SMODS.Joker{ --Scarlet Forest
    key = "scarletforest",
    config = {
        extra = {
            Mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Scarlet Forest',
        ['text'] = {
            [1] = 'This Joker gains {C:red}+3{} Mult if played hand',
            [2] = 'contains a {C:attention}Flush{} of #2# {C:inactive}(Currently {}{C:red}+#1# {}{C:inactive}Mult){}',
            [3] = '{s:0.85}(Suit changes each round){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Mult, localize((G.GAME.current_round.ChosenSuit_card or {}).suit or 'Spades', 'suits_singular')}, colours = {G.C.SUITS[(G.GAME.current_round.ChosenSuit_card or {}).suit or 'Spades']}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.ChosenSuit_card = { suit = 'Spades' }
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.Mult
                }
        end
        if context.before and context.cardarea == G.jokers  then
            if (next(context.poker_hands["Flush"]) and (function()
    local allMatchSuit = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:is_suit(G.GAME.current_round.ChosenSuit_card.suit)) then
            allMatchSuit = false
            break
        end
    end
    
    return allMatchSuit and #context.scoring_hand > 0
end)()) then
                return {
                    func = function()
                    card.ability.extra.Mult = (card.ability.extra.Mult) + 3
                    return true
                end
                }
            end
        end
    end
}