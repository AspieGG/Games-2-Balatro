SMODS.Joker{ --Tough Times
    key = "toughtimes",
    config = {
        extra = {
            dollars = 14
        }
    },
    loc_txt = {
        ['name'] = 'Tough Times',
        ['text'] = {
            [1] = 'Earn {C:money}$14{} at end of round if {C:attention}0 hands and discards{} remain'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (G.GAME.current_round.hands_left == 0 and G.GAME.current_round.discards_left == 0) then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
    end
}