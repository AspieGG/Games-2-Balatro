SMODS.Joker{ --Wizard
    key = "wizard",
    config = {
        extra = {
            xMult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Wizard',
        ['text'] = {
            [1] = 'This Joker gains {X:red,C:white}X0.5{} Mult whenever a {C:spectral}Spectral{}',
            [2] = 'card is used {C:inactive}(Currently {}{X:red,C:white}X#1#{}{C:inactive} Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xMult}}
    end,

    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Spectral' then
                return {
                    func = function()
                    card.ability.extra.xMult = (card.ability.extra.xMult) + 0.5
                    return true
                end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xMult
                }
        end
    end
}