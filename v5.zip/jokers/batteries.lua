SMODS.Joker{ --Batteries
    key = "batteries",
    config = {
        extra = {
            Mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Batteries',
        ['text'] = {
            [1] = 'This Joker gains {C:red}+1{} Mult whenever a played',
            [2] = 'Ace is scored {C:inactive}(Currently {}{C:red}+#1#{}{C:inactive} Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Mult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 14 then
                card.ability.extra.Mult = (card.ability.extra.Mult) + 1
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.Mult
                }
        end
    end
}