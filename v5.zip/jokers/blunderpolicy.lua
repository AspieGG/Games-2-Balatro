SMODS.Joker{ --Blunder Policy
    key = "blunderpolicy",
    config = {
        extra = {
            LuckyTrigger = 0,
            luckycardsinhand = 1
        }
    },
    loc_txt = {
        ['name'] = 'Blunder Policy',
        ['text'] = {
            [1] = 'If played hand does not trigger a {C:attention}Lucky{} card,',
            [2] = '{X:red,C:white}X1{} Mult per {C:attention}Lucky{} card in played hand.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_lucky"] == true then
            count = count + 1
        end
    end
    return count > 0
end)() and (card.ability.extra.LuckyTrigger or 0) == 0) then
                return {
                    Xmult = card.ability.extra.luckycardsinhand + ((function() local count = 0; for _, card in ipairs(G.hand and G.hand.cards or {}) do if SMODS.has_enhancement(card, 'm_lucky') then count = count + 1 end end; return count end)())
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card.lucky_trigger then
                card.ability.extra.LuckyTrigger = 1
            end
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.LuckyTrigger = 0
                    return true
                end
                }
        end
    end
}