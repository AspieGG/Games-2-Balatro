SMODS.Joker{ --Clubs Sandwich
    key = "clubssandwich",
    config = {
        extra = {
            Chips = 40
        }
    },
    loc_txt = {
        ['name'] = 'Clubs Sandwich',
        ['text'] = {
            [1] = 'Each played card of {C:clubs}Club{} suit gives {C:blue}+#1#{} Chips',
            [2] = 'when scored. Reduces by {C:blue}5{} at end of round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chips}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Clubs") then
                return {
                    chips = card.ability.extra.Chips
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (card.ability.extra.Chips or 0) >= 10 then
                return {
                    func = function()
                    card.ability.extra.Chips = math.max(0, (card.ability.extra.Chips) - 5)
                    return true
                end
                }
            elseif (card.ability.extra.Chips or 0) <= 5 then
                return {
                    func = function()
                card:undefined()
                return true
            end
                }
            end
        end
    end
}