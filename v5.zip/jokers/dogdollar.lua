SMODS.Joker{ --Dog Dollar
    key = "dogdollar",
    config = {
        extra = {
            Bought = 0,
            sell_value = 25,
            sell_value2 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Dog Dollar',
        ['text'] = {
            [1] = 'Loses {C:money}$3{} of sell value at end of round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'buf' and args.source ~= 'jud' 
          or args.source == 'sho' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  and not context.blueprint then
                return {
                    func = function()local my_pos = nil
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] == card then
                my_pos = i
                break
            end
        end
        local target_card = G.jokers.cards[my_post]for i, target_card in ipairs(area.cards) do
                if target_card.set_cost then
            target_joker.ability.extra_value = card.ability.extra.sell_value
            target_joker:set_cost()
            end
        end
                    return true
                end,
                    message = "Sell Value: $"..tostring(card.ability.extra.sell_value),
                    extra = {
                        func = function()
                    card.ability.extra.Bought = 1
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if (card.ability.extra.Bought or 0) == 1 then
                return {
                    func = function()local my_pos = nil
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] == card then
                my_pos = i
                break
            end
        end
        local target_card = G.jokers.cards[my_post]for i, target_card in ipairs(area.cards) do
                if target_card.set_cost then
            target_joker.ability.extra_value = math.max(0, (card.ability.extra_value or 0) - card.ability.extra.sell_value2)
            target_joker:set_cost()
            end
        end
                    return true
                end,
                    message = "Value Down!"
                }
            end
        end
    end
}