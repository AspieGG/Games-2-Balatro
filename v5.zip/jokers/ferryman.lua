SMODS.Joker{ --Ferryman
    key = "ferryman",
    config = {
        extra = {
            dollars = 10
        }
    },
    loc_txt = {
        ['name'] = 'Ferryman',
        ['text'] = {
            [1] = 'Earn {C:money}$10{} whenever a Blind is skipped.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.skip_blind  then
                return {
                    dollars = card.ability.extra.dollars
                }
        end
    end
}