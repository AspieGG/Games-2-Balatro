SMODS.Joker{ --Final Gambit
    key = "finalgambit",
    config = {
        extra = {
            Lose = 4,
            Xmult = 4
        }
    },
    loc_txt = {
        ['name'] = 'Final Gambit',
        ['text'] = {
            [1] = '{X:red,C:white}X4{} Mult. Lose the run if held for 5 rounds'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.Xmult
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if (card.ability.extra.Lose or 0) <= 0 then
                return {
                    func = function()
                
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.5,
                    func = function()
                        if G.STAGE == G.STAGES.RUN then 
                          G.STATE = G.STATES.GAME_OVER
                          G.STATE_COMPLETE = false
                        end
                    end
                }))
                
                return true
            end
                }
            else
                return {
                    func = function()
                    card.ability.extra.Lose = math.max(0, (card.ability.extra.Lose) - 1)
                    return true
                end
                }
            end
        end
    end
}