SMODS.Joker{ --Gold Widow
    key = "goldwidow",
    config = {
        extra = {
            dollars = 8
        }
    },
    loc_txt = {
        ['name'] = 'Gold Widow',
        ['text'] = {
            [1] = 'Earn {C:money}$8{} at end of round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    dollars = card.ability.extra.dollars
                }
        end
    end
}