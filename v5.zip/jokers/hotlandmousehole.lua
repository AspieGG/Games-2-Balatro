SMODS.Joker{ --Hotland Mouse Hole
    key = "hotlandmousehole",
    config = {
        extra = {
            Xmult = 1.2
        }
    },
    loc_txt = {
        ['name'] = 'Hotland Mouse Hole',
        ['text'] = {
            [1] = 'Each {C:attention}2{} held in hand gives {X:red,C:white}X1.2{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card:get_id() == 2 then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}