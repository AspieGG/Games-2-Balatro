SMODS.Joker{ --Ice Wolf
    key = "icewolf",
    config = {
        extra = {
            chips = 40
        }
    },
    loc_txt = {
        ['name'] = 'Ice Wolf',
        ['text'] = {
            [1] = 'If played hand contains a Two Pair, each played',
            [2] = 'card gives {C:blue}+40{} Chips when scored.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if next(context.poker_hands["Two Pair"]) then
                return {
                    chips = card.ability.extra.chips
                }
            end
        end
    end
}