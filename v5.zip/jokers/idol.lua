SMODS.Joker{ --Idol
    key = "idol",
    config = {
        extra = {
            start_dissolve = 0,
            y = 0
        }
    },
    loc_txt = {
        ['name'] = 'Idol',
        ['text'] = {
            [1] = '{C:red}-2{} hand size. Prevents death. {C:red}Self-destructs{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over and context.main_eval  and not context.blueprint then
                return {
                    saved = true,
                    message = localize('k_saved_ex'),
                    extra = {
                        func = function()
                card:start_dissolve()
                return true
            end,
                            message = "+Iconoclasm",
                        colour = G.C.RED
                        }
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(-2)
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(2)
    end
}