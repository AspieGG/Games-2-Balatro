SMODS.Joker{ --Incinerator Room
    key = "incineratorroom",
    config = {
        extra = {
            Active = 0,
            Xmult = 3
        }
    },
    loc_txt = {
        ['name'] = 'Incinerator Room',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult if a card was destroyed this round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.remove_playing_cards  then
                return {
                    func = function()
                    card.ability.extra.Active = 1
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (card.ability.extra.Active or 0) == 1 then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.Active = 0
                    return true
                end
                }
        end
    end
}