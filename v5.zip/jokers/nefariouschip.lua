SMODS.Joker{ --Nefarious Chip
    key = "nefariouschip",
    config = {
        extra = {
            currenthandsize = 0
        }
    },
    loc_txt = {
        ['name'] = 'Nefarious Chip',
        ['text'] = {
            [1] = '{C:blue}+10{} Chips per hand size {C:inactive}(Currently {}{C:blue}+#1#{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {(((G.hand and G.hand.config.card_limit or 0) or 0)) * 10}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = ((G.hand and G.hand.config.card_limit or 0)) * 10
                }
        end
    end
}