SMODS.Joker{ --Pyrefly Forest
    key = "pyreflyforest",
    config = {
        extra = {
            Count = 0,
            dollars = 8
        }
    },
    loc_txt = {
        ['name'] = 'Pyrefly Forest',
        ['text'] = {
            [1] = 'Earn {C:money}$8{} every 8 cards discarded'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.discard  then
            if (card.ability.extra.Count or 0) < 7 then
                return {
                    func = function()
                    card.ability.extra.Count = (card.ability.extra.Count) + 1
                    return true
                end
                }
            elseif (card.ability.extra.Count or 0) >= 7 then
                return {
                    dollars = card.ability.extra.dollars,
                    extra = {
                        func = function()
                    card.ability.extra.Count = 0
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            end
        end
    end
}