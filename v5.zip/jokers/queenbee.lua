SMODS.Joker{ --Queen Bee
    key = "queenbee",
    config = {
        extra = {
            Count = 6,
            Xmult = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Queen Bee',
        ['text'] = {
            [1] = 'Every sixth scored card of {C:diamonds}Diamond{} suit gives {X:red,C:white}X2.5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:is_suit("Diamonds") and (card.ability.extra.Count or 0) ~= 6) then
                card.ability.extra.Count = (card.ability.extra.Count) + 1
            elseif (context.other_card:is_suit("Diamonds") and (card.ability.extra.Count or 0) == 6) then
                card.ability.extra.Count = 1
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}