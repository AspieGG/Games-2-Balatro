SMODS.Joker{ --Star Crystals
    key = "starcrystals",
    config = {
        extra = {
            odds = 5
        }
    },
    loc_txt = {
        ['name'] = 'Star Crystals',
        ['text'] = {
            [1] = 'Each played card of {C:diamonds}Diamond{} suit has a{C:green} 1 in 6{}',
            [2] = 'chance to create a {C:planet}Planet{} card when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Diamonds") then
                if SMODS.pseudorandom_probability(card, 'group_0_412eb47b', 1, card.ability.extra.odds, 'j_g2b_starcrystals', false) then
              local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Planet', soulable = nil, key = nil, key_append = 'joker_forge_planet'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_consumable and localize('k_plus_planet') or nil, colour = G.C.SECONDARY_SET.Planet})
          end
            end
        end
    end
}