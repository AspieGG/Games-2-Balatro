SMODS.Joker{ --Tough Glove
    key = "toughglove",
    config = {
        extra = {
            chips_min = 10,
            chips_max = 40,
            mult = 5
        }
    },
    loc_txt = {
        ['name'] = 'Tough Glove',
        ['text'] = {
            [1] = 'Each played 5 gives {C:blue}+10-40{} Chips and {C:red}+5{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 5 then
                return {
                    chips = pseudorandom('chips_bec79d16', card.ability.extra.chips_min, card.ability.extra.chips_max),
                    extra = {
                        mult = card.ability.extra.mult
                        }
                }
            end
        end
    end
}