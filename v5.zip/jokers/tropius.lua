SMODS.Joker{ --Tropius
    key = "tropius",
    config = {
        extra = {
            mult = 15,
            odds = 6,
            Xmult = 3
        }
    },
    loc_txt = {
        ['name'] = 'Tropius',
        ['text'] = {
            [1] = '{C:red}+15{} Mult',
            [2] = '{C:green}1 in 6{}{C:green}{} chance for {X:red,C:white}X3{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    mult = card.ability.extra.mult
                ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_a4f5288f', 1, card.ability.extra.odds, 'j_g2b_tropius', false) then
              SMODS.calculate_effect({Xmult = card.ability.extra.Xmult}, card)
          end
                        return true
                    end
                }
            end
        end
    end
}