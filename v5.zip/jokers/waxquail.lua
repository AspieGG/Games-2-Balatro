SMODS.Joker{ --Wax Quail
    key = "waxquail",
    config = {
        extra = {
            AlreadyTriggered = 0,
            Chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Wax Quail',
        ['text'] = {
            [1] = '{C:blue}+10{} Chips per card with a Seal',
            [2] = 'triggered this Ante {C:inactive}(Currently {}{C:blue}+#2#{}{C:blue}{}{C:inactive} Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.AlreadyTriggered, card.ability.extra.Chips}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.Chips
                }
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card.seal == "Gold" then
                card.ability.extra.Chips = (card.ability.extra.Chips) + 10
            elseif context.other_card.seal == "Red" then
                card.ability.extra.Chips = (card.ability.extra.Chips) + 10
            end
        end
        if context.discard  then
            if context.other_card.seal == "Purple" then
                return {
                    func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 10
                    return true
                end
                }
            end
        end
        if context.cardarea == G.hand and context.end_of_round  then
            if context.other_card.seal == "Blue" then
                return {
                    func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 10
                    return true
                end
                }
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
                return {
                    func = function()
                    card.ability.extra.Chips = 0
                    return true
                end,
                    message = "Reset!"
                }
        end
    end
}