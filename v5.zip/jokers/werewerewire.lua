SMODS.Joker{ --Werewerewire
    key = "werewerewire",
    config = {
        extra = {
            mult = 11
        }
    },
    loc_txt = {
        ['name'] = 'Werewerewire',
        ['text'] = {
            [1] = 'Each played Mult card gives {C:red}+11{} Mult when scored.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["g2b_g2b_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_mult"] == true then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}