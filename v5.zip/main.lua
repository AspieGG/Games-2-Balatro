SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end

load_jokers_folder()
SMODS.ObjectType({
    key = "g2b_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "g2b_g2b_jokers",
    cards = {
        ["j_g2b__57leafclover"] = true,
        ["j_g2b_bibliox"] = true,
        ["j_g2b_blunderpolicy"] = true,
        ["j_g2b_bonnie"] = true,
        ["j_g2b_castletown"] = true,
        ["j_g2b_cow"] = true,
        ["j_g2b_cyborg"] = true,
        ["j_g2b_dogdollar"] = true,
        ["j_g2b_doubleedge"] = true,
        ["j_g2b_dungeon"] = true,
        ["j_g2b_emptygun"] = true,
        ["j_g2b_fadedribbon"] = true,
        ["j_g2b_finalgambit"] = true,
        ["j_g2b_firestarter"] = true,
        ["j_g2b_frequencies"] = true,
        ["j_g2b_gengar"] = true,
        ["j_g2b_giratina"] = true,
        ["j_g2b_goldwidow"] = true,
        ["j_g2b_goldplatedbomb"] = true,
        ["j_g2b_golem"] = true,
        ["j_g2b_golfer"] = true,
        ["j_g2b_greenhouse"] = true,
        ["j_g2b_guei"] = true,
        ["j_g2b_guzzlord"] = true,
        ["j_g2b_harpoon"] = true,
        ["j_g2b_heartlocket"] = true,
        ["j_g2b_hotlandmousehole"] = true,
        ["j_g2b_icewolf"] = true,
        ["j_g2b_idol"] = true,
        ["j_g2b_incineratorroom"] = true,
        ["j_g2b_isabeau"] = true,
        ["j_g2b_jakiro"] = true,
        ["j_g2b_johngutter"] = true,
        ["j_g2b_lancercookie"] = true,
        ["j_g2b_ledian"] = true,
        ["j_g2b_loadeddice"] = true,
        ["j_g2b_lucario"] = true,
        ["j_g2b_ludicolo"] = true,
        ["j_g2b_mauswheel"] = true,
        ["j_g2b_milotic"] = true,
        ["j_g2b_mirabelle"] = true,
        ["j_g2b_muffet"] = true,
        ["j_g2b_ponman"] = true,
        ["j_g2b_punchcard"] = true,
        ["j_g2b_pyreflyforest"] = true,
        ["j_g2b_queenbee"] = true,
        ["j_g2b_ruinsmousehole"] = true,
        ["j_g2b_sapling"] = true,
        ["j_g2b_spectraldagger"] = true,
        ["j_g2b_starcrystals"] = true,
        ["j_g2b_temyarmor"] = true,
        ["j_g2b_toughglove"] = true,
        ["j_g2b_toughtimes"] = true,
        ["j_g2b_tropius"] = true,
        ["j_g2b_werewerewire"] = true,
        ["j_g2b_worndagger"] = true
    },
})